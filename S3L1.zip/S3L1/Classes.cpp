#pragma once

Sequence<Number> *generateArray()
{
	return new Array<Number>;
}

Sequence<Number> *generateList()
{
	return new List<Number>;
}
