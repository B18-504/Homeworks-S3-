#include "TestMacro.h"

void Test1()
{
	Result res;
	res.passed = 0;
	res.total = 0;
	
}
